#ifndef HW_POWER_H
#define HW_POWER_H

// No power control in S5L8920

#endif

