This folder contains tidbits of information about the design of
OpeniBoot, and the hardware it's designed to run on.

Please put files in a readable format (such as PDF, or txt) in
a suitable path under this folder.
