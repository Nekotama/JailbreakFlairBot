#ifndef  __A4_HARDWARE_RADIO
#define  __A4_HARDWARE_RADIO

#define RADIO_UART 1

#endif //__A4_HARDWARE_RADIO
